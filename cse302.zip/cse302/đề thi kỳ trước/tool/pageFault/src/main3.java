
public class main3 {

    static int[] referenceString
            = {4, 7, 6, 1, 7, 6, 1, 2, 7, 2};
    static int frameSize = 3;
    // kiểu chữ Consolas
    // 1: true,    0:false
    static int OPT = 0;
    static int LRU = 1;
    static int FIFO = 0;

    
    public static void main(String[] args) {
        PageReplacement pr = new PageReplacement();
        //
        if (OPT==1) {
            System.out.println("=== Optimal Page Replacement ===");
            pr.optimalAlgorithm(referenceString, frameSize);
        }
        if (LRU==1) {
            System.out.println("\n=== Least Recently Used (LRU) Page Replacement ===");
            pr.lruAlgorithm(referenceString, frameSize);
        }
        if (FIFO==1) {
            System.out.println("\n=== First In First Out (FIFO) Page Replacement ===");
            pr.fifoAlgorithm(referenceString, frameSize);
        }
   }
}
