
import java.util.ArrayList;
import java.util.Arrays;

public class main2 {

    static int[] available = {2, 1, 1};

    static int[][] allocation = {
        {2, 1, 3},
        {1, 2, 3},
        {5, 4, 3},
        {2, 1, 2},};

    static int[][] maximum = {
        {4, 9, 4},
        {5, 3, 3},
        {6, 4, 3},
        {4, 8, 2},};

    // request
    static int[] request = {2, 0, 0};
    static int custID = 0;

    public static void main(String[] args) {
        try {
            Banker banker = new Banker(available, maximum, allocation);
            System.out.println("Need: " + Arrays.deepToString(banker.getNeed()) + "\n");
            System.out.println("Initial Safe State: " + banker.isSafeState() + "\n");

            //
            if(request.length>0){
                System.out.println("-".repeat(50));
                System.out.println("- requset:");
            }
            ArrayList<Integer> result = banker.request(custID, request);
            if (result != null) {
                System.out.println("Request granted. System remains in a safe state.");
                System.out.println("Initial Safe State: " + result + "\n");
            } else {
                System.out.println("Request denied. System would be in an unsafe state.\n");
            }

        } catch (Exception e) {
        }
    }
}
