
import java.util.ArrayList;
import java.util.Arrays;

public class main3 {
    public static void main(String[] args) {
        int[] available = {1, 5, 2, 0};
        int[][] allocation = {
            {0, 0, 1, 2},
            {1, 0, 0, 0},
            {1, 3, 5, 4},
            {0, 6, 3, 2},
            {0, 0, 1, 4}
        };
        int[][] maximum = {
            {0, 0, 1, 2},
            {1, 7, 5, 0},
            {2, 3, 5, 6},
            {0, 6, 5, 2},
            {0, 6, 5, 6}
        };
        
        try {
            Banker banker = new Banker(available, maximum, allocation);
            System.out.println("Initial Safe State: " + banker.isSafeState());
            //
            int[] request = {0, 4, 2, 0};
            ArrayList<Integer> result = banker.request(1, request);
            if (result != null) {
                System.out.println("Request granted. System remains in a safe state.");
                System.out.println("Initial Safe State: " + result);
                System.out.println("Current state: ");
                System.out.println("Available: " + Arrays.toString(banker.getAvailable()));
                System.out.println("Allocation: " + Arrays.deepToString(banker.getAllocation()));
                System.out.println("Need: " + Arrays.deepToString(banker.getNeed()));
            } else {
                System.out.println("Request denied. System would be in an unsafe state.");
            }
        } catch (Exception e) {
        }
    }
}
