
public class main1 {
    public static void main(String[] args) {
        DiningPhilosophers1 dp1 = new DiningPhilosophers1();
        philosopher1 p0 = new philosopher1(0, dp1);
        philosopher1 p1 = new philosopher1(1, dp1);
        philosopher1 p2 = new philosopher1(2, dp1);
        philosopher1 p3 = new philosopher1(3, dp1);
        philosopher1 p4 = new philosopher1(4, dp1);
        p0.start();
        p1.start();
        p2.start();
        p3.start();
        p4.start();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
        }
        p0.shutdown();
        p1.shutdown();
        p2.shutdown();
        p3.shutdown();
        p4.shutdown();
    }
}
class philosopher1 extends Thread{
    private int id;
    private DiningPhilosophers1 dp1;
    private boolean stop = true;
    public philosopher1(int id, DiningPhilosophers1 dp1){
        this.id = id;
        this.dp1 = dp1;
    }
    @Override
    public void run(){
        while (this.stop) {
            System.out.println("thinking "+id);
            try {
                Thread.sleep(100);
                System.out.println("get Forks "+id);
                this.dp1.getForks(this.id);
                
            } catch (InterruptedException e) {
            }
            
            System.out.println("eating "+id);
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
            }
            System.out.println("release Forks "+id);
            this.dp1.releaseForks(this.id);
        }
    }
    public void shutdown(){
        this.stop=false;
    }
}