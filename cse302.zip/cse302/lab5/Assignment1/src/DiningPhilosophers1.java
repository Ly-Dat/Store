
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class DiningPhilosophers1 {

    private final int N = 5;
    private ReentrantLock lock = new ReentrantLock();
    private Condition Cond = this.lock.newCondition();
    private ReentrantLock[] forks;

    public DiningPhilosophers1() {
        this.forks = new ReentrantLock[N];
        for (int i = 0; i < N; i++) {
            this.forks[i] = new ReentrantLock();
        }
    }

    public void getForks(int id) throws InterruptedException {
        this.lock.lock();
        try {
            int rightFork = id;
            int leftFork = (id + 1) % N;
            if (id % 2 == 0) {
                while (forks[rightFork].isLocked()) {
                    Cond.await();
                }
                forks[rightFork].lock();
                while (forks[leftFork].isLocked()) {
                    Cond.await();
                }
                forks[leftFork].lock();
            } else {
                while (forks[leftFork].isLocked()) {
                    Cond.await();
                }
                forks[leftFork].lock();
                while (forks[rightFork].isLocked()) {
                    Cond.await();
                }
                forks[rightFork].lock();
            }
        } finally {
            this.lock.unlock();
        }
    }

    public void releaseForks(int id) {
        this.lock.lock();
        try {
            int rightFork = id;
            int leftFork = (id + 1) % N;
            forks[leftFork].unlock();
            forks[rightFork].unlock();
            Cond.signal();

        } finally {
            this.lock.unlock();
        }
    }
}
