
import java.util.ArrayList;
import java.util.Arrays;

public class main4 {

    public static void main(String[] args) {
        int[] available = {3, 3, 2};
        int[][] maximum = {
            {7, 5, 3},
            {3, 2, 2},
            {9, 0, 2},
            {2, 2, 2},
            {4, 3, 3}
        };
        int[][] allocation = {
            {0, 1, 0},
            {2, 0, 0},
            {3, 0, 2},
            {2, 1, 1},
            {0, 0, 2}
        };
        try {
            Banker banker = new Banker(available, maximum, allocation);
            System.out.println("Initial Safe State: " + banker.isSafeState());
            //
            int[] request = {1, 0, 2};
            ArrayList<Integer> result = banker.request(1, request);
            if (result != null) {
                System.out.println("Request granted. System remains in a safe state.");
                System.out.println("Current state: ");
                System.out.println("Available: " + Arrays.toString(banker.getAvailable()));
                System.out.println("Allocation: " + Arrays.deepToString(banker.getAllocation()));
                System.out.println("Need: " + Arrays.deepToString(banker.getNeed()));
            } else {
                System.out.println("Request denied. System would be in an unsafe state.");
            }
        } catch (Exception e) {
        }
    }
}
