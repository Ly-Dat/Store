import java.util.ArrayList;
import java.util.Random;

public class main2 {
    public static void main(String[] args) {
        DiningPhilosophers2 dp2 = new DiningPhilosophers2();

        ArrayList<philosopher> list = new ArrayList<>();
        for(int i=0; i<5; i++){
            list.add(new philosopher(dp2));
        }
        list.forEach(p->p.start());
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
        }
        list.forEach(p->p.shutdown());
    }
}
class philosopher extends Thread{
    static Random rd = new Random();
    private DiningPhilosophers2 dp2;
    private boolean stop = true;
    public philosopher(DiningPhilosophers2 dp2){
        this.dp2 = dp2;
    }
    @Override
    public void run(){
        while (this.stop) {
            try {
                //thinking
                System.out.println("thinking ");
                Thread.sleep(100);
                
                //get Forks
                System.out.println("get Forks ");
                this.dp2.getForks();
            } catch (InterruptedException e) {
                
            }
            
            try {
                //eating
                System.out.println("eating ");
                Thread.sleep(rd.nextInt(100));
            } catch (InterruptedException e) {
                
            }
            //release Forks
            System.out.println("release Forks ");
            this.dp2.releaseForks();
        }
    }
    public void shutdown(){
        this.stop=false;
    }
}
