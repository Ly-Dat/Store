
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class DiningPhilosophers2 {

    private final int N = 5;
    private int remainForks = N;
    private int eatingCount = 0;
    private ReentrantLock lock = new ReentrantLock();
    private Condition cond = this.lock.newCondition();

    public DiningPhilosophers2() {

    }

    public void getForks() throws InterruptedException {
        this.lock.lock();
        try {
            // get firt focks
            while(true){
                if (this.remainForks > 1 || this.remainForks == 1 && eatingCount > 0) {
                    this.remainForks--;
                    break;
                } else {
                    cond.await();
                }
            }

            // get second focks
            while(true){
                if (this.remainForks > 0) {
                    this.remainForks--;
                    this.eatingCount++;
                    break;
                }
                else {
                    cond.await();
                }
            }
            
        } finally {
            this.lock.unlock();
        }

    }

    public void releaseForks() {
        this.lock.lock();
        try {
            this.eatingCount--;
            this.remainForks += 2;
            this.cond.signalAll();
            // check
            System.out.println(remainForks);
        } finally {
            this.lock.unlock();
        }
    }
}
