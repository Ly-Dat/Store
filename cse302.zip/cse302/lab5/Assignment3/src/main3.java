
public class main3 {

    public static void main(String[] args) {
        Bank bank = new Bank(4, 1000);
        Thread t1 = new Banking(bank, 1, 2, 200);
        Thread t2 = new Banking(bank, 2, 3, 1100);
        t1.start();
        t2.start();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
        }
        System.out.println(bank.check());
    }
}
class Banking extends Thread{
    private boolean success;
    private Bank bank;
    private int fromId;
    private int toId;
    private double amount;
    
    public Banking(Bank bank, int fromId, int toId, double amount) {
        this.bank = bank;
        this.fromId = fromId;
        this.toId = toId;
        this.amount = amount;
    }

    @Override
    public void run(){
        this.success=bank.transaction(fromId, toId, amount);
        System.out.println("Transaction "+fromId+" to "+toId+" : "+success);
    }
}
