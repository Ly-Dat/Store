
import java.util.ArrayList;

public class Bank {

    private ArrayList<Account> accounts = new ArrayList<>();

    public Bank(int accountNum, int balance) {
        for (int i = 0; i < accountNum; i++) {
            Account acc = new Account(i, balance);
            this.accounts.add(acc);
        }
    }

    private Account find(int id) {
        for (int i = 0; i < this.accounts.size(); i++) {
            if (this.accounts.get(i).getId() == id) {
                return this.accounts.get(i);
            }
        }
        return null;
    }

    public boolean transaction(int fromId, int told, double amount) {
        Account from = this.find(fromId);
        if (from == null) {
            return false;
        }
        Account to = this.find(told);
        if (to == null) {
            return false;
        }
        return this.transaction(from, to, amount);
    }

    private boolean transaction(Account from, Account to, double amount) {
        Account lock1 = (System.identityHashCode(from) < System.identityHashCode(to)) ? from : to;
        Account lock2 = (lock1 == from) ? to : from;

        lock1.lock.lock();
        try {
            lock2.lock.lock();
            try {
                if (from.getBalance() < amount) {
                    return false;
                }
                from.setBalance(from.getBalance() - amount);
                to.setBalance(to.getBalance() + amount);
                return true;
            } finally {
                lock2.lock.unlock();
            }

        } finally {
            lock1.lock.unlock();
        }
    }
    public double check(){
        double sum = 0;
        for(var t : accounts){
            sum+=t.getBalance();
        }
        return sum;
    }
}
