public class Main4 {
    public static void main(String[] args) throws InterruptedException {
        MyBarrier myBarrier = new MyBarrier(3);
        TestRunable tr1 = new TestRunable(myBarrier);
        Thread t1 = new Thread(tr1);
        t1.start();

        TestRunable tr2 = new TestRunable(myBarrier);
        Thread t2 = new Thread(tr2);
        t2.start();

        TestRunable tr3 = new TestRunable(myBarrier);
        Thread t3 = new Thread(tr3);
        t3.start();

        t1.join();
        t2.join();
        t3.join();

        System.out.println("done");


    }
}
class TestRunable implements Runnable{
    private MyBarrier barrier;

    public TestRunable(MyBarrier barrier) {
        this.barrier = barrier;
    }
    
    @Override
    public void run(){
        try {
            this.barrier.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
