import java.util.LinkedList;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;

public class TSQueue {
    LinkedList<Integer> queue = new LinkedList<>();
    private Lock lock = new ReentrantLock();

    public void addLast(int val) {
        this.lock.lock();
        try {
            this.queue.addLast(val);
        } finally {
            this.lock.unlock();
        }
    }

    public int removeFirst() {
        int value;
        this.lock.lock();
        try {
            if (this.queue.isEmpty() == false) {
                throw new IllegalStateException("Queue is empty");
            }
            value = this.queue.removeFirst();
            return value;
        } finally {
            this.lock.unlock();
        }
    }

    public boolean isEmpty() {
        this.lock.lock();
        try {
            return this.queue.isEmpty();
        } finally {
            this.lock.unlock();
        }
    }

    public LinkedList<Integer> getQueue() {
        return (LinkedList<Integer>) this.queue.clone();
    }

}
