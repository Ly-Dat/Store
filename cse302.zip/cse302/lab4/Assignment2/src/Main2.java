public class Main2 {
    static int N;

    public static void main(String[] args) throws InterruptedException {
        N = 10;
        TSQueue queue = new TSQueue();
        Thread t1 = new addLastThread(queue);
        Thread t2 = new removeFirstThread(queue);

        t1.start();
        t2.start();
        t1.join();
        t2.join();
        if(queue.isEmpty()) {
            System.out.println("queue is empty");
        }
        else{
            System.out.println(queue.getQueue().size());
        }
        
    }
}

class addLastThread extends Thread {
    TSQueue queue;

    public addLastThread(TSQueue queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        for (int i = 0; i < Main2.N; i++) {
            queue.addLast(i);
        }
    }
}

class removeFirstThread extends Thread {
    TSQueue queue;

    public removeFirstThread(TSQueue queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        for (int i = 0; i < Main2.N; i++) {
            queue.removeFirst();
        }
    }
}
