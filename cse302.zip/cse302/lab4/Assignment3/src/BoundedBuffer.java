import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedBuffer {
    private int size;
    private LinkedList<Integer> buffer = new LinkedList<>();
    private Lock lock = new ReentrantLock();
    private Condition fullCond = this.lock.newCondition();
    private Condition emptyCond = this.lock.newCondition();

    public BoundedBuffer(int val) {
        this.size = val;
    }

    public void add(int v) throws InterruptedException {
        this.lock.lock();
        try {
            if (this.buffer.size() == this.size) {
                this.fullCond.await();
            }
            this.buffer.addLast(v);
            this.emptyCond.signal();
        } finally {
            this.lock.unlock();
        }
    }

    public int remove() throws InterruptedException {
        int value;
        this.lock.lock();
        try {
            if(this.buffer.isEmpty()==true){
                this.emptyCond.await();
            }
            value = this.buffer.removeFirst();
            this.fullCond.signal();
            return value;
        } finally {
            this.lock.unlock();
        }
    }

    public LinkedList<Integer> getBufer() {
        return (LinkedList<Integer>) this.buffer.clone();
    }
}
