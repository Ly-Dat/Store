import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Data {
    int sharedData;
    private Lock lock = new ReentrantLock();
    private Semaphore sem = new Semaphore(1);
    
        public Data(int val) {
            this.sharedData = val;
        }
    
    
        // synchronized
    
    
        public synchronized void increase(){
        this.sharedData++;
        }
    
        public synchronized void decrease(){
        this.sharedData--;
        }
    
    
    
        // ReentrantLock
    
        // public void increase() {
        //     this.lock.lock();
        //     this.sharedData++;
        //     this.lock.unlock();
        // }
    
        // public void decrease() {
        //     this.lock.lock();
        //     this.sharedData--;
        //     this.lock.unlock();
        // }
    
    
    
        // Semaphore
    
    //     public void increase() throws InterruptedException{
    //         this.sem.acquire();
    //     try{
    //         this.sharedData++;
    //     }
    //     finally{
    //         this.sem.release();
    //     }
    //     }
    
    //     public void decrease() throws InterruptedException{
    //     this.sem.acquire();
    //     try{
    //         this.sharedData--;
    //     }
    //     finally{
    //         this.sem.release();
    //     }
        
        
    // }

    public int getSharedData() {
        return sharedData;
    }

}
