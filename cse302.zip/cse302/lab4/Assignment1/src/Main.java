public class Main {
    static int N;
    public static void main(String[] args) throws InterruptedException {
        N = 100000;
        Data shareData = new Data(N);
        Thread t1 = new IncreaseThread(shareData);
        Thread t2 = new DecreaseThread(shareData);
        
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        System.out.println(shareData.getSharedData());
        
    }
    

}

class IncreaseThread extends Thread{
    Data shareData;

    public IncreaseThread(Data i){
        this.shareData=i;
    }

    @Override
    public void run(){
        for(int i =0; i<Main.N; i++){
            this.shareData.increase();


            // Semaphore

            // try {
            //     this.shareData.increase(); 
            // } catch (InterruptedException e) {
            //     e.printStackTrace();
            // }
        }
    }
}

class DecreaseThread extends Thread {
    Data shareData;

    public DecreaseThread(Data i){
        this.shareData=i;
    }

    @Override
    public void run() {
        for(int i =0; i<Main.N; i++){
            this.shareData.decrease();


            // Semaphore

            // try {
            //     this.shareData.decrease();  
            // } catch (InterruptedException e) {
            //     e.printStackTrace();
            // }
        }
    }
}
