
import java.util.ArrayList;
import java.util.Random;


public class Main5 {

    public static void main(String[] args) throws InterruptedException{
        Random rd = new Random();
        ArrayList<Thread> threads = new ArrayList<>();
        OldBrigde oldBrigde = new OldBrigde();
        for (int i = 0; i < 10; i++) {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run(){
                    try {
                        int dir = rd.nextInt();
                        oldBrigde.arriveBridge(dir%2);
                        // on the brigde
                        Thread.sleep(10);
                        oldBrigde.exitBridge(dir%2);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            threads.add(t);
            t.start();
        }
        for(Thread t:threads){
            t.join();
        }
        System.out.println();
      
    }
}
