
import java.util.ArrayList;
import java.util.Random;

public class main4 {

    public static void main(String[] args) throws InterruptedException{
        SecondReadersWriters sw = new SecondReadersWriters();
        ArrayList<ReadThread> listRead = new ArrayList<>();
        ArrayList<WriteThread> listWrite = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            ReadThread t = new ReadThread(sw);
            t.start();
            listRead.add(t);
        }
        for (int i = 0; i < 5; i++) {
            WriteThread t = new WriteThread(sw);
            t.start();
            listWrite.add(t);
        }
        Thread.sleep(1000);

        for(ReadThread t:listRead){
            t.shutdown();
        }
        for(WriteThread t:listWrite){
            t.shutdown();
        }


    }
}

class ReadThread extends Thread {
    private Random rd = new Random();
    private SecondReadersWriters sw;
    private boolean running = true;

    public ReadThread(SecondReadersWriters sw) {
        this.sw = sw;
    }
    @Override
    public void run() {
        try {
            while (running) {
                this.sw.read_enter();

                System.out.println("reading");
                
                Thread.sleep(rd.nextInt(100));
                
                this.sw.read_exit();
                System.out.println("done");
                Thread.sleep(rd.nextInt(100));
                
            }
        } catch (InterruptedException e) {

        }
    }
    public void shutdown() {
        this.interrupt();
        this.running = false;
    }
}
class WriteThread extends Thread {
    private Random rd = new Random();
    private SecondReadersWriters sw;
    private boolean running = true;

    public WriteThread(SecondReadersWriters sw) {
        this.sw = sw;
    }

    @Override
    public void run() {
        try {
            while (running) {
                this.sw.write_enter();

                System.out.println("writting");
                
                Thread.sleep(rd.nextInt(100));
                
                this.sw.write_exit();
                System.out.println("done");
                Thread.sleep(rd.nextInt(100));
                
            }
        } catch (InterruptedException e) {

        }
    }
    public void shutdown() {
        this.interrupt();
        this.running = false;

    }
}
