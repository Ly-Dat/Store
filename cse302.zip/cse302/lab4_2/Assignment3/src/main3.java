
import java.util.ArrayList;

public class main3 {

    public static void main(String[] args) throws InterruptedException{
        FirstReadersWriters rw = new FirstReadersWriters();
        ArrayList<ReadThread> listRead = new ArrayList<>();
        ArrayList<WriteThread> listWrite = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            ReadThread t = new ReadThread(rw);
            t.start();
            listRead.add(t);
        }
        for (int i = 0; i < 10; i++) {
            WriteThread t = new WriteThread(rw);
            t.start();
            listWrite.add(t);
        }

        Thread.sleep(100);

        for(ReadThread t:listRead){
            t.shutdown();
        }
        for(WriteThread t:listWrite){
            t.shutdown();
        }


    }
}

class ReadThread extends Thread {
    private FirstReadersWriters fw;
    private boolean running = true;

    public ReadThread(FirstReadersWriters fw) {
        this.fw = fw;
    }
    @Override
    public void run() {
        try {
            while (running) {
                this.fw.read_enter();

                System.out.println("reading");
                
                Thread.sleep(10);
                
                this.fw.read_exit();
                System.out.println("done");
                Thread.sleep(10);
                
            }
        } catch (InterruptedException e) {

        }
    }
    public void shutdown() {
        this.interrupt();
        this.running = false;
    }
}
class WriteThread extends Thread {

    private FirstReadersWriters fw;
    private boolean running = true;

    public WriteThread(FirstReadersWriters fw) {
        this.fw = fw;
    }

    @Override
    public void run() {
        try {
            while (running) {
                this.fw.write_enter();

                System.out.println("writting");
                
                Thread.sleep(10);
                
                this.fw.write_exit();
                System.out.println("done");
                Thread.sleep(10);
                
            }
        } catch (InterruptedException e) {

        }
    }
    public void shutdown() {
        this.interrupt();
        this.running = false;
    }
}
