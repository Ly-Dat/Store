import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class FirstReadersWriters {
    private ReentrantLock lock = new ReentrantLock();
    private Condition readCond = this.lock.newCondition();
    private Condition writeCond = this.lock.newCondition();
    private int readCount=0;
    private int writeCount=0;


    public void read_enter() throws InterruptedException{
        this.lock.lock();
        try {
            while(this.writeCount==1){
                this.readCond.await();
            }
            this.readCount++;
            this.check();
        } finally {
            this.lock.unlock();
        }
    }

    //

    public void read_exit(){
        this.lock.lock();
        try {
            this.readCount--;
            if(this.readCount==0){
                this.writeCond.signal();
            }
            this.check();
        } finally {
            this.lock.unlock();
        }
    }

    //

    public void write_enter() throws InterruptedException{
        this.lock.lock();
        try {
            while(this.readCount>0 || this.writeCount>0){
                this.writeCond.await();
            }
            this.writeCount=1;
            this.check();
        } finally {
            this.lock.unlock();
        }
    }

    //

    public void write_exit(){
        this.lock.lock();
        try {
            this.writeCount=0;
            this.readCond.signalAll();
            this.writeCond.signal();
            this.check();
        } finally {
            this.lock.unlock();
        }
    }
    public void check(){
        if(readCount>0 && writeCount>0){
            System.out.println("error");
        }
    }
}
