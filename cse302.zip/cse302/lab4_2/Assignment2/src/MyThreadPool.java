
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class MyThreadPool {

    private static boolean running = true;
    private int size;
    private ArrayList<Thread> threads = new ArrayList<>();
    private LinkedList<Runnable> tasks = new LinkedList<>();
    private ReentrantLock lock = new ReentrantLock();
    private Condition cond = this.lock.newCondition();

    public MyThreadPool(int size) {
        this.size = size;
        for (int i = 0; i < this.size; i++) {
            Thread t = new Thread(() -> {
                while (running) {
                    Runnable task = null;
                    this.lock.lock();
                    try {
                        if (!running && tasks.isEmpty()) {
                            return;
                        }
                        task = tasks.poll();
                    } finally {
                        lock.unlock();
                    }
                    if (task != null) {
                        task.run();
                    }
                }
            });
            threads.add(t);
            t.start();
        }
    }

    public MyThreadPool() {
        this(3);
    }

    public void add(Runnable task) {
        this.lock.lock();
        try {
            this.tasks.add(task);
            this.cond.signalAll();

        } finally {
            this.lock.unlock();
        }
    }

    public void shutdown() throws InterruptedException {
        this.lock.lock();
        try {
            this.running = false;
            this.cond.signalAll();
        } finally {
            this.lock.unlock();
        }

    }
}
