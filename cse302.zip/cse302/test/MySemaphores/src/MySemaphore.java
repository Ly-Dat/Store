
import java.util.ArrayList;
import java.util.List;

public class MySemaphore {

    private int value;
    private List<Thread> waitingList = new ArrayList<>();
    public MySemaphore(int value) {
        this.value = value;
    }

    public synchronized void acquire() throws InterruptedException{
        if(value>0){
            value--;
        }
        else{
            Thread th = Thread.currentThread();
            waitingList.add(th);
            wait();
        }
    }
    public synchronized void release(){
        if(waitingList.isEmpty()){
            value++;
        }
        else{
            notify();
        }
        
    }
    
}
