int value = 10

int main(){
    pid_t pid;
    pid = fork();
    if(pid<0){
    a=1;
    }
}
