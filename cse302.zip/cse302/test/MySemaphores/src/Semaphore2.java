
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Semaphore2 {

    int value;
    int count = 0;
    private Lock lock = new ReentrantLock();
    private Condition cond = this.lock.newCondition();

    public Semaphore2(int value) {
        this.value = value;
    }

    public void acquire() throws InterruptedException {
        try {
            if (value > 0) {
                value--;
            } else {
                count++;
                this.cond.await();
                count--;
            }
        } finally {
            this.lock.unlock();
        }
    }

    public void release() {
        this.lock.lock();
        try {
            if (count > 0) {
                lock.unlock();
                cond.signal();
            } else {
                value++;
            }
        } finally {
            this.lock.unlock();
        }

    }

}
