
import java.util.Scanner;

public class main2 {

    public static void main(String[] args) {
        ContiguousAllocator cma = new ContiguousAllocator(4096);
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.print("allocator> ");
            String cmdLine = sc.nextLine();
            cmdLine = cmdLine.trim();
            cmdLine = cmdLine.toUpperCase();
            if (cmdLine.equals("Q")) {
                break;
            }
            String[] a = cmdLine.split("\\s+");
            boolean result = false;
            switch (a[0]) {
                case "SIZE":
                    if (a.length != 2) {
                        continue;
                    }
                    try {
                        cma.changeSize(Integer.parseInt(a[1]));
                        System.out.println("change size done");
                        break;
                    } catch (NumberFormatException e) {
                        continue;
                    }
                case "RQ":
                    if (a.length != 4) {
                        continue;
                    }
                    switch (a[3]) {
                        case "F":
                            try {
                                result = cma.requestFirstFit(a[1], Integer.parseInt(a[2]));
                                break;
                            } catch (NumberFormatException e) {
                                continue;
                            }
                        case "B":
                            try {
                                result = cma.requestBestFit(a[1], Integer.parseInt(a[2]));
                                break;
                            } catch (NumberFormatException e) {
                                continue;
                            }
                        case "W":
                            try {
                                result = cma.requestWorstFit(a[1], Integer.parseInt(a[2]));
                                break;
                            } catch (NumberFormatException e) {
                                continue;
                            }
                    }
                    if (!result) {
                        System.out.println("can not request");
                    } else {
                        System.out.println("request done!");
                    }
                    break;
                case "RL":
                    if (a.length != 2) {
                        continue;
                    }
                    cma.release(a[1]);
                    System.out.println("release done!");
                    break;
                case "C":
                    cma.compact();
                    System.out.println("compact done!");
                    break;
                case "STAT":
                    System.out.println(cma.state());
                    break;
            }
        }

    }
}
