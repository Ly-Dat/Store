public class MultithreadingExample {
    public static void main(String[] args) {
        App runable = new App();
        // t.start();
        // try {
        //     t.join();
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // }

        Thread thread = new Thread(runable);
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
