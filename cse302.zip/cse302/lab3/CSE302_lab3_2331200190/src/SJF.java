
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class SJF extends Scheduler {

    @Override
    public List<String> schedule(List<Task> queue) {
        List<String> output = new ArrayList<>();
        List<Task> taskQ = new LinkedList<>();
        for (Task task : queue) {
            taskQ.add(new Task(task));
        }
        int currentTime = 0;
        taskQ.sort((p1, p2) -> {
            int a = Integer.compare(p1.getBurst(), p2.getBurst());
            if (a == 0) {
                return Integer.compare(p1.getPriority(), p2.getPriority());
            }
            return a;
        });
        for (Task task : taskQ) {
            int duration = task.getBurst();
            output.add(currentTime + " : " + task.toString() + " - Duration: " + duration);
            currentTime += duration;
        }
        return output;
    }
}
