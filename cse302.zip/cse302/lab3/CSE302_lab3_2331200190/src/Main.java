
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException {
        String filename = "Schedule.txt";
        List<Task> tasks = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        
        while (true) {
            String line = br.readLine();
            if(line==null){
                break;
            }
            String[] a = line.split(", ");
            tasks.add(new Task(a[0], Integer.parseInt(a[1]), Integer.parseInt(a[2])));
        }
        // FCFC
        Scheduler fcfs = new FCFS();
        List<String> fcfsSchedule = fcfs.schedule(tasks);
        System.out.println("FCFS Schedule:");
        fcfsSchedule.forEach(System.out::println);
        System.out.println("-".repeat(30)+"\n");

        // SJF
        Scheduler sjf = new SJF();
        List<String> sjfSchedule = sjf.schedule(tasks);
        System.out.println("SJF Schedule:");
        sjfSchedule.forEach(System.out::println);
        System.out.println("-".repeat(30)+"\n");

        // Priority
        Scheduler priority = new Priority();
        List<String> prioritySchedule = priority.schedule(tasks);
        System.out.println("Priority Schedule:");
        prioritySchedule.forEach(System.out::println);
        System.out.println("-".repeat(30)+"\n");

        // round-robin
        int slice = 4;
        Scheduler roundRobin = new RR();
        List<String> roundRobinSchedule = roundRobin.schedule(tasks, slice);
        System.out.println("round-robin Schedule:");
        roundRobinSchedule.forEach(System.out::println);
        System.out.println("-".repeat(30)+"\n");

        // Priority with round-robin
        int slice1 = 4;
        Scheduler priority_RR = new Priority_RR();
        List<String> priority_RRSchedule = priority_RR.schedule(tasks, slice1);
        System.out.println("Priority with round-robin Schedule:");
        priority_RRSchedule.forEach(System.out::println);
        System.out.println();
        
    }
}
