
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class RR extends Scheduler {

    @Override
    public List<String> schedule(List<Task> queue, int slice) {
        List<String> output = new ArrayList<>();
        List<Task> taskQ = new LinkedList<>();
        for (Task task : queue) {
            taskQ.add(new Task(task));
        }
        Queue<Task> taskQueue = new LinkedList<>(taskQ);
        int currentTime = 0;
        while (!taskQueue.isEmpty()) {
            Task currentTask = taskQueue.poll();
            if (currentTask.getBurst() > slice) {
                output.add(currentTime + " : " + currentTask.toString() + " - Duration: " + slice);
                currentTask.burst -= slice;
                taskQueue.add(currentTask);
                currentTime += slice;
            } else {
                output.add(currentTime + " : " + currentTask.toString() + " - Duration: " + currentTask.getBurst());
                currentTime += currentTask.getBurst();
            }
        }
        return output;
    }
}
