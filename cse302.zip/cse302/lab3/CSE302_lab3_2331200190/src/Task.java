public class Task {
    String name;
    int priority;
    int burst;

    Task(String name, int priority, int burst) {
        this.name = name;
        this.priority = priority;
        this.burst = burst;
    }
    public Task(Task other) {
        this.name = other.name; 
        this.priority = other.priority;
        this.burst = other.burst; 
    }

    public String getName() {
        return name;
    }

    public int getPriority() {
        return priority;
    }

    public int getBurst() {
        return burst;
    }
    
    @Override
    public String toString() {
        return name + " - Pri: " + priority + " - Burst: " + burst;
    }
}
