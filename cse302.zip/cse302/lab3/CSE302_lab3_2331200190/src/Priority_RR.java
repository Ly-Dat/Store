
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Priority_RR extends Scheduler {

    @Override
    public List<String> schedule(List<Task> queue, int slice) {
        List<String> output = new ArrayList<>();
        List<Task> taskQ = new LinkedList<>();
        for (Task task : queue) {
            taskQ.add(new Task(task));
        }
        taskQ.sort((p1, p2) -> p1.getPriority() - p2.getPriority());
        Queue<Task> taskQueue = new LinkedList<>(taskQ);
        int currentTime = 0;
        Queue<Task> a = new LinkedList<>();
        while (!taskQueue.isEmpty()) {
            Task task1 = taskQueue.poll();
            Task task2 = taskQueue.peek();
            if(task2 == null){
                task2 = new Task(null,-1, 0);
            }
            if (task1.getPriority() != task2.getPriority()) {
                if (a.isEmpty()) {
                    int duration = task1.getBurst();
                    output.add(currentTime + " : " + task1.toString() + " - Duration: " + duration);
                    currentTime += duration;
                }
                else{
                    a.add(task1);
                    // RR
                    while (!a.isEmpty()) {
                        Task currentTask = a.poll();
                        if (currentTask.getBurst() > slice) {
                            output.add(currentTime + " : " + currentTask.toString() + " - Duration: " + slice);
                            currentTask.burst -= slice;
                            a.add(currentTask);
                            currentTime+=slice;
                        } else {
                            output.add(currentTime + " : " + currentTask.toString() + " - Duration: " + currentTask.getBurst());
                            currentTime+=currentTask.getBurst();
                        }
                    }
                    a = new LinkedList<>();
                }
            } else {
                a.add(task1);
            }

        }
        return output;
    }
}
