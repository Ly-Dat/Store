
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class test {
    public static void main(String[] args) {
        HashMap<String, Integer> map = new HashMap<>();
        List<HashMap<String, Integer>> arr = new ArrayList<>();
        map.put("1", 2);
        map.put("12", 1);
        map.put("13", 1);
        map.put("14", 1);
        map.put("15", 1);

        map.entrySet().stream().sorted((p1, p2) ->{
            int a = Integer.compare(p1.getValue(), p2.getValue());
            if(a==0){
                System.out.println(p1.getKey()+"hi\n");
            }
            return a;
        });
    }
}
