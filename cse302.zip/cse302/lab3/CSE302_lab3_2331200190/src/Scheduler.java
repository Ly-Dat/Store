
import java.util.List;

public abstract class Scheduler {
    
    public List<String> schedule(List<Task> queue) {
        return null;
    }

    public List<String> schedule(List<Task> queue, int a) {
        return null;
    }
}
