import java.util.Arrays;

public class Max_finding implements Runnable {  
    int[] value;
    int result;
    public Max_finding(int[] value) {
        this.value = value;
    }
    
    public int getValue() {
        return result;
    }

    @Override
    public void run(){
        result = Arrays.stream(value).max().orElse(Integer.MIN_VALUE);
    }
}
