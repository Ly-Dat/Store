import java.util.Arrays;

public class  Average_calculation implements Runnable{
    int[] value;
    double averageValue = 0;
    public Average_calculation(int[] value) {
        this.value = value;
    }
    
    public int getValue() {
        return (int)averageValue;
    }

    @Override
    public void run(){
        int sum = Arrays.stream(value).sum();
        averageValue= (double)sum/value.length;
    }
    
}
