public class Main2{
    public static void main(String[] args) throws InterruptedException {
        int[] numbers ={90, 81, 78, 95, 79, 72, 85};
        Average_calculation average = new Average_calculation(numbers);
        Min_finding min = new Min_finding(numbers);
        Max_finding max = new Max_finding(numbers);
        Thread avThread= new Thread(average);
        Thread minThread = new Thread(min);
        Thread maxThread = new Thread(max);
        avThread.start();
        avThread.join();
        System.out.println("The average value is " + average.getValue());
        minThread.start();
        minThread.join();
        System.out.println("The minimum value is " + min.getValue());
        maxThread.start();
        maxThread.join();
        System.out.println("The maximum value is " + max.getValue());
    }
}