import java.util.Arrays;

public class Min_finding implements Runnable{  
    int[] value;
    int result;
    public Min_finding(int[] value) {
        this.value = value;
    }
    
    public int getValue() {
        return result;
    }

    @Override
    public void run(){
        result = Arrays.stream(value).min().orElse(Integer.MAX_VALUE);
    }
}
