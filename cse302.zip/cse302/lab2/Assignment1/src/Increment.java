public class Increment implements Runnable {
    ShareData1 shareData;

    public Increment(ShareData1 shareData) {
        this.shareData = shareData;
    }

    @Override
    public void run() {
        for(int i=0; i<1000000; i++){
            shareData.increment();
        }
    }
   
}
