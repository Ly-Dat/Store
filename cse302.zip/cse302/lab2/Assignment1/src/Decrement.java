public class Decrement implements Runnable {
    ShareData1 shareData;

    public Decrement(ShareData1 shareData) {
        this.shareData = shareData;
    }

    @Override
    public void run() {
        for(int i=0; i<1000000; i++){
            shareData.decrement();
        }
    }
}
