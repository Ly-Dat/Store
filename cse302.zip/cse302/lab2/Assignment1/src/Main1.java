
public class Main1 {

    static ShareData1 shareData;
 
    public static void main(String[] args) throws InterruptedException {
        shareData = new ShareData1();
        // Scenario A
        System.out.println("Scenario A:");
        Thread increase = new Thread(new Increment(shareData));
        Thread decrease = new Thread(new Decrement(shareData));
        increase.start();
        increase.join();
        decrease.start();
        decrease.join();
        System.out.println("final value: " + shareData.getValue()); 
        
        // Scenario B
        shareData = new ShareData1();
        System.out.println("Scenario B:");
        increase = new Thread(new Increment(shareData));
        decrease = new Thread(new Decrement(shareData));
        increase.start();
        decrease.start();
        decrease.join();
        increase.join();
        System.out.println("final value: " + shareData.getValue());
    }
}
