public class Fibonacci implements Runnable{
    int a;
    long[] arr;
    public Fibonacci(int a) {
        this.a = a;
        this.arr = new long[a];
        this.arr[0]=0;
        this.arr[1]=1;
    }
    public long[] getValue() {
        return arr;
    }
    @Override
    public void run(){
        for(int i=2; i<a; i++){
            arr[i]=arr[i-1]+arr[i-2];
        }
    }
}
