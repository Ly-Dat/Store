
import java.util.Scanner;

public class Main5 {

    public static void main(String[] args) throws InterruptedException{
        StringBuilder sb = new StringBuilder();
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of Fibonacci numbers: ");
        int num = sc.nextInt();
        Fibonacci fibonacci = new Fibonacci(num);
        Thread fibo = new Thread(fibonacci);
        fibo.start();
        fibo.join();
        for(long i: fibonacci.getValue()){
            sb.append(i+" ");
        }
        System.out.println(num+" Fibonacci numbers:\n"+sb);
    }
}