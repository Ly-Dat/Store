public class Main4 {
    public static void main(String[] args) throws InterruptedException{
        int num = 1000000;
        Pi_Finding pi = new Pi_Finding(num);
        Thread thCount = new Thread(pi);
        thCount.start();
        thCount.join();
        System.out.println("value of π is "+pi.getValue());
    }
}
