import java.util.Random;

public class Pi_Finding implements Runnable{
    static Random rd = new Random();
    int a;
    double result = 0;
    public Pi_Finding(int a) {
        this.a = a;
    }
    
    public double getValue() {
        return result;
    }

    @Override
    public void run(){
        for(int i=0; i<a; i++){
            double x = rd.nextDouble(-1, 1);
            double y = rd.nextDouble(-1, 1);
            if(x*x + y*y <=1){
                this.result++;
            }
        }
        this.result=result*4/a;
    }
}
