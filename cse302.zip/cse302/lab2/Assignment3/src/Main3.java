
import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) throws InterruptedException {
        StringBuffer sb = new StringBuffer();
        System.out.print("Enter a number: ");
        Scanner sc = new Scanner(System.in);
        int numbers = sc.nextInt();
        Prime_finding prime =  new Prime_finding(numbers);
        Thread thprime = new Thread(prime);
        thprime.start();
        thprime.join();
        for(int i:prime.getValue()){
            sb.append(i+" ");
        }
        System.out.println("Prime numbers:\n"+sb);
    }
}
