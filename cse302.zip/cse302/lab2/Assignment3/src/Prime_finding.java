import java.util.ArrayList;
import java.util.List;

public class Prime_finding implements Runnable {
    List<Integer> result = new ArrayList<>();
    int a;
    public Prime_finding(int a) {
        this.a=a;
    }

    public List<Integer> getValue() {
        return result;
    }

    @Override
    public void run() {
        for(int i=0; i<=a; i++){
            if(i==2){
                result.add(i);
            }
            else if(i>2){
                boolean flag = true;
                for(int j=2; j<=Math.sqrt(i); j++){
                    if(i%j==0){
                        flag=false;
                        break;
                    }
                }
                if(flag){
                    result.add(i);
                }
            }
        }
    }
}
